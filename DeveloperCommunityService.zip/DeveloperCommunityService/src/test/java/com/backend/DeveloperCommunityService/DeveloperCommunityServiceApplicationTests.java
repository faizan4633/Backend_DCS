package com.backend.DeveloperCommunityService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeveloperCommunityServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
