package com.dcs.util;

public enum VoteType {
	UPVOTE, DOWNVOTE
}